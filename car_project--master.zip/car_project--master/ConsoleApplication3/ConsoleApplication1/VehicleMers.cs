﻿using System;

namespace ConsoleApplication1
{
    public class VehicleMers: Vehicle, IComparable<VehicleMers> 
    {
        public VehicleMers(string name, string colour, int weigth, double price, int mileage, MotoEngine engine) 
            : base(name, colour, weigth, price, mileage, engine) { }
        public int CompareTo(VehicleMers other)
        {
            return (int) (Price - other.Price);
        }

        public override string ToString()
        {
            return $"{base.ToString()}  Colour - {Colour}  Price - {Price}";
        }
    }
}
