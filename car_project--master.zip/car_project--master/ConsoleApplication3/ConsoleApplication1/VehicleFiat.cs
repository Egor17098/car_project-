﻿using System;

namespace ConsoleApplication1
{
    class VehicleFiat: Vehicle, IConvertible
    {
        public VehicleFiat(string name, string colour, int weigth, double price, int mileage, MotoEngine engine) 
            : base(name, colour, weigth, price, mileage, engine) { }

        public TypeCode GetTypeCode()
        {
            return Weigth.GetTypeCode();
        }

        public bool ToBoolean(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToBoolean(provider);
        }

        public char ToChar(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToChar(provider);
        }

        public sbyte ToSByte(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToSByte(provider);
        }

        public byte ToByte(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToByte(provider);
        }

        public short ToInt16(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToByte(provider);
        }

        public ushort ToUInt16(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToUInt16(provider);
        }

        public int ToInt32(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToInt32(provider);
        }

        public uint ToUInt32(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToUInt32(provider);
        }

        public long ToInt64(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToInt64(provider);
        }

        public ulong ToUInt64(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToUInt64(provider);
        }

        public float ToSingle(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToSingle(provider);
        }

        public double ToDouble(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToDouble(provider);
        }

        public decimal ToDecimal(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToDecimal(provider);
        }

        public DateTime ToDateTime(IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToDateTime(provider);
        }

        public string ToString(IFormatProvider provider)
        {
            return (Weigth as IConvertible).ToString(provider);
        }

        public object ToType(Type conversionType, IFormatProvider provider)
        {
            return ((IConvertible) Weigth).ToType(conversionType, provider);
        }

        public override string ToString()
        {
            return $"{base.ToString()}  Colour - {Colour}  Price - {Price}";
        }
    }
}
