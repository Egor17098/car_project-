﻿namespace ConsoleApplication1
{
    public abstract class AbstractVehicle
    {
        public string Name { get; set; }
        public string Colour { get; set; }

        protected AbstractVehicle(string name, string colour) : this()
        {
            Name = name;
            Colour = colour;
        }

        protected AbstractVehicle() { }
    }
}
