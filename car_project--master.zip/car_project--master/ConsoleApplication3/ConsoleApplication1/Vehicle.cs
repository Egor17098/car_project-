﻿using System;
using System.Linq;

namespace ConsoleApplication1
{
    public class Vehicle: Moto, Moto.MotoEngine.IDelivery
    {
        public static int Count { get; set; }
        public MotoEngine Engine { get; set; }
        public int Weigth { get; set; }
        public double Price { get; set; }
        public int Mileage { get; set; }

        public delegate void TaxEventHandler(object source, EventArgs args);

        public event TaxEventHandler Tax;

        protected virtual void OnTax()
        {
            Tax?.Invoke(this, EventArgs.Empty);
        }

        public void Encode(MotoEngine moto)
        {
            Count = moto.CountСylinder;
            Engine = moto;
            OnTax();
        }

        public Vehicle(string name, string colour, int weigth, double price, int mileage, MotoEngine engine) : base(name, colour)
        {
            Weigth = weigth;
            Price = price;
            Mileage = mileage;
            Engine = engine;
        }

        public Vehicle() { }

        public static int CountId { get; set; }

        public static int CountCar
        {
            get
            {
                return CountId;
            }
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException(nameof(value));
                CountId = value;
            }
        }

        public static void MaxMinPrice( double min,  double max, double[] price)
        {
            if (price.Length > 0)
            {
                min = price[0];
                max = price[0];
            }
            if (CountId != price.Length) return;
            for (int i = 0; i < CountId; i++)
            { 
                if (max < price[i])
                    max = price[i];
                if (min > price[i])
                    min = price[i];
            }
        }

        private static int[] _brok;

        public void CarBrok(int size)
        {
            _brok = new int[size];
        }

        public int this[int index]
        {
            set
            {
                if (value >= 0)
                    _brok[index] = value;
                else
                {
                    throw new ArgumentOutOfRangeException(nameof(value));
                }
            }
            get { return _brok[index]; }
                
        }

        public int SumBrok()
        {
            return _brok.Sum();
        }

        public void Day()
        {
            Random rnd = new Random();
            int a = rnd.Next(30);
            Console.WriteLine("Delivery after " + a + "days");
        }

        public override string ToString()
        {
            return $"Name - {Name} Price - {Price} Country - {Engine.Country}";
        }


    }
}
