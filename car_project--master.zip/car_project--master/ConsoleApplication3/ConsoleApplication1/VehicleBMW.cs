﻿namespace ConsoleApplication1
{
    class VehicleBmw: Vehicle
    {
        public VehicleBmw(string name, string colour, int weigth, double price, int mileage, MotoEngine engine) 
            : base(name, colour, weigth, price, mileage, engine) { }

        public VehicleBmw() { }

        public override string ToString()
        {
            return $"{base.ToString()}  Colour - {Colour}  Price - {Price}";
        }
    }
}
