﻿using System;

namespace ConsoleApplication1
{
    public class LuxuryTax
    {
        public void OnTax(object source, EventArgs e)
        {
            Console.WriteLine("You have the luxury tax for your vehicle");
        }

        public void OffTax(object source, EventArgs e)
        {
            Console.WriteLine("You don't have the luxury tax, becouse your car is worth less than $ 40,000");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            if (args == null)
                throw new ArgumentNullException(nameof(args));

            Console.WriteLine("Input the namber of Mers: ");
            Vehicle.CountCar = Convert.ToInt32(Console.ReadLine());
            var countMers = Vehicle.CountCar;
            var luxuryTax = new LuxuryTax();
            var mers = new VehicleMers[countMers]; 
            var mersMoto = new Moto.MotoEngine[countMers];
            for (int i = 0; i < countMers; i++)
            {
                try
                {
                    Console.WriteLine("Mers: " + (i + 1));
                    Console.WriteLine("Name: ");
                    string name = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Colour: ");
                    string colour = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Weigth: ");
                    int weigth = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Price: ");
                    double price = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Mileage: ");
                    int mileage = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Elements engine: ");
                    Console.WriteLine("Type: ");
                    string type = Convert.ToString(Console.ReadLine());
                    Console.WriteLine("Volume: ");
                    int volume = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("CountСylinder: ");
                    int countСylinder = Convert.ToInt32(Console.ReadLine());
                    string country = mersMoto[i].Producers();

                    mersMoto[i] = new Moto.MotoEngine(type, volume, countСylinder, country);
                    mers[i] = new VehicleMers(name, colour, weigth, price, mileage, mersMoto[i]);
                }
                catch (ArgumentNullException)
                {
                    Console.WriteLine("One of the argument is Null");
                    mers[i] = new VehicleMers("", "", 0, 0, 0, mersMoto[i]);
                    mersMoto[i] = new Moto.MotoEngine("", 0, 0, "");
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    mers[i] = new VehicleMers("", "", 0, 0, 0, mersMoto[i]);
                    mersMoto[i] = new Moto.MotoEngine("", 0, 0, "");
                }
                if (mers[i].Price > 40000)
                {
                    mers[i].Tax += luxuryTax.OnTax;
                    mers[i].Encode(mersMoto[i]);
                }
                else
                {
                    mers[i].Tax += luxuryTax.OffTax;
                    mers[i].Encode(mersMoto[i]);
                }
            }

            Console.WriteLine("Input the namber of BMW: ");
            Vehicle.CountCar = Convert.ToInt32(Console.ReadLine());
            var countBmw = Vehicle.CountCar;
            var bmw = new VehicleBmw[countBmw];
            var bmwMoto = new Moto.MotoEngine[countBmw];
            for (int i = 0; i < countBmw; i++)
            {
                Console.WriteLine("BMW: " + (i + 1));
                Console.WriteLine("Name: ");
                string name = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Colour: ");
                string colour = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Weigth: ");
                int weigth = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Price: ");
                double price = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Mileage: ");
                int mileage = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Elements engine: ");
                Console.WriteLine("Type: ");
                string type = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Volume: ");
                int volume = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("CountСylinder: ");
                int countСylinder = Convert.ToInt32(Console.ReadLine());
                string country = bmwMoto[i].Producers();

                try
                {
                    bmwMoto[i] = new Moto.MotoEngine(type, volume, countСylinder, country);
                    bmw[i] = new VehicleBmw(name, colour, weigth, price, mileage, bmwMoto[i]);

                }
                catch (ArgumentNullException)
                {
                    Console.WriteLine("One of the argument is Null");
                    bmw[i] = new VehicleBmw("", "", 0, 0, 0, mersMoto[i]);
                    bmwMoto[i] = new Moto.MotoEngine("", 0, 0, "");
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    bmw[i] = new VehicleBmw("", "", 0, 0, 0, mersMoto[i]);
                    bmwMoto[i] = new Moto.MotoEngine("", 0, 0, "");
                }

                var i1 = i;
                bmw[i].Tax += (source, eventArgs) => ((bmw[i1].Price > 40000) ? (Vehicle.TaxEventHandler)luxuryTax.OnTax : luxuryTax.OffTax)(source, eventArgs); //Console.WriteLine("You have the luxury tax for your vehicle");
                //bmw[i].Tax += (source, eventArgs) => (source, eventArgs); //Console.WriteLine("You don't have the luxury tax, becouse your car is worth less than $ 40,000");
                bmw[i].Encode(bmwMoto[i]);
            }


            Console.WriteLine("Input the namber of Fiat: ");
            Vehicle.CountCar = Convert.ToInt32(Console.ReadLine());
            var countFiat = Vehicle.CountCar;
            var fiat = new VehicleFiat[countFiat];
            var fiatMoto = new Moto.MotoEngine[countFiat];
            for (int i = 0; i < countFiat; i++)
            {
                Console.WriteLine("Fiat: " + (i + 1));
                Console.WriteLine("Name: ");
                string name = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Colour: ");
                string colour = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Weigth: ");
                int weigth = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Price: ");
                double price = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Mileage: ");
                int mileage = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Elements engine: ");
                Console.WriteLine("Type: ");
                string type = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Volume: ");
                int volume = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("CountСylinder: ");
                int countСylinder = Convert.ToInt32(Console.ReadLine());
                string country = fiatMoto[i].Producers();
                try
                {
                    fiatMoto[i] = new Moto.MotoEngine(type, volume, countСylinder, country);
                    fiat[i] = new VehicleFiat(name, colour, weigth, price, mileage, fiatMoto[i]);
                }
                catch (ArgumentNullException)
                {
                    Console.WriteLine("One of the argument is Null");
                    fiat[i] = new VehicleFiat("", "", 0, 0, 0, mersMoto[i]);
                    fiatMoto[i] = new Moto.MotoEngine("", 0, 0, "");
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    fiat[i] = new VehicleFiat("", "", 0, 0, 0, mersMoto[i]);
                    fiatMoto[i] = new Moto.MotoEngine("", 0, 0, "");
                }
                
                if (fiat[i].Price >= 40000)
                {
                    fiat[i].Tax += delegate
                    { Console.WriteLine("You have the luxury tax for your vehicle"); };
                    fiat[i].Encode(fiatMoto[i]);
                }
                else
                {
                    fiat[i].Tax += delegate 
                    {  Console.WriteLine("You don't have the luxury tax, becouse your car is worth less than $ 40,000"); };
                    fiat[i].Encode(fiatMoto[i]);
                }
            }

            Console.ReadKey();

            // ReSharper disable once FunctionNeverReturns
        }
    }
}
