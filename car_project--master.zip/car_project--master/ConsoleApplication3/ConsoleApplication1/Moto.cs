﻿using System;


namespace ConsoleApplication1
{
    public class Moto: AbstractVehicle
    {
        public Moto(string name, string colour) : base(name, colour) { }

        public Moto() { }

        public enum Countries
        {
            Germany,
            Russia,
            Italy,
            France
        }

        public struct MotoEngine
        {
            public string Type { get; set; }
            public int Volume { get; set; }
            public int CountСylinder { get; set; }
            public string Country { get; set; }

            public MotoEngine(string type, int volume, int countCylinder, string country)
            {
                Type = type;
                Volume = volume;
                CountСylinder = countCylinder;
                Country = country;
            }

            public string Producers()
            {
                Console.WriteLine("Choose a producer:");
                Console.WriteLine("1 - Germany\n2 - Russia\n3 - Italy\n4 - France\n");
                string number = Console.ReadLine();
                string countryname = Enum.GetNames(typeof (Countries))[Convert.ToInt32(number) - 1];
                Country = Convert.ToString(Enum.Parse(typeof (Countries), countryname));
                return Country;
            }

            public interface IDelivery
            {
                void Day();
            }
        }
    }
}
